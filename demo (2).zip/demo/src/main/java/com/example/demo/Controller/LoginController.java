package com.example.demo.Controller;

import com.example.demo.Entity.Login;
import com.example.demo.SErvice.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/logins")
@CrossOrigin(origins = "*")  // Enable CORS for this controller
public class LoginController {

    @Autowired
    private LoginService loginService;

    // Save a new login
    @PostMapping
    public ResponseEntity<Login> createLogin(@RequestBody Login login) {
        Login savedLogin = loginService.saveLogin(login);
        return ResponseEntity.ok(savedLogin);
    }

    // Get all logins
    @GetMapping
    public ResponseEntity<List<Login>> getAllLogins() {
        List<Login> logins = loginService.getAllLogins();
        return ResponseEntity.ok(logins);
    }

    // Get login by ID
    @GetMapping("/{id}")
    public ResponseEntity<Optional<Login>> getLoginById(@PathVariable Long id) {
        Optional<Login> login = loginService.getLoginById(id);
        return ResponseEntity.ok(login);
    }

    // Delete login by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLogin(@PathVariable Long id) {
        loginService.deleteLogin(id);
        return ResponseEntity.noContent().build();
    }
}
